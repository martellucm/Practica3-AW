<?php
	namespace es\ucm\fdi\aw;
	use es\ucm\fdi\aw\Aplicacion as App;
	require_once __DIR__.'/../comun/config.php';
	require_once __DIR__.'/../comun/Form.php';
	require_once __DIR__.'/Producto.php';

class RegistroProducto extends Form {
	const HTML5_EMAIL_REGEXP = '^[a-zA-Z0-9.!#$%&\'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$';

	  public function __construct()
	  {
	    parent::__construct('formProducto');
	  }


	protected function procesaFormulario($datos){
			$result = array();
			$ok = true;

			$nombreProducto = $datos['_nombreProducto']??'';

			if ( !$nombreProducto || mb_strlen($nombreProducto) < 1 ) {
				$result[] = "El nombre del producto tiene que tener una longitud de al menos 1 caracter.";
			}

			$descrip = $datos['_descrip']??'';
			
			if (!$descrip || mb_strlen($descrip) < 5 ) {
				$result[] = "La descripción tiene que tener una longitud de al menos 5 caracteres.";
				$ok = false;
			}

			$edad = $datos['_edad']??'';
			
			if (!$edad) {
				$result[] = "Introduce la edad recomendada";
				$ok = false;
			}
			$jugadores = $datos['_jugadores']??'';
			
			if ($jugadores  == 0) {
				$result[] = "Debe introducir el numero de jugadores.";
				$ok = false;
			}

			$link = $datos['_link']??'';
			if (!$link) {
				$result[] = "Debe introducir el link de compra.";
				$ok = false;

			}

			$empresa = $datos['_empresa']??'';
			if ( !$empresa) {
				$result[] = "Imtroduce el nombre de la empresa propietaria.";
				$ok = false;
			}

			if ($ok) {
				$producto = Product::crea($nombreProducto, 0, $descrip, $edad, $jugadores,$link,$empresa, '0');
				if (! $producto ) {
					$result[] = "El producto ya existe";
				} else {
					$result = \es\ucm\fdi\aw\Aplicacion::getSingleton()->resuelve('/prodtabla.php');
				}
			}

			return $result;
		}

	protected function generaCamposFormulario($datosIniciales){
			$nombrProd = '';
			$descrip = '';
			$edad = 0;
			$jugadores = 0;
			$link = '';
			$empresa = '';

			/*
			* En caso de que hubiera un error se mantienen
			* los datos para que puedas modificarlos
			*/

			if($datosIniciales){
				$nombrProd = $datosIniciales['_nombreProducto'] ?? $nombrProd;
				$descrip = $datosIniciales['_descrip'] ?? $descrip;
				$edad = $datosIniciales['_edad'] ?? $descrip;
				$jugadores = $datosIniciales['_jugadores'] ?? $jugadores;
				$link = $datosIniciales['_link'] ?? $link;
				$empresa = $datosIniciales['_empresa'] ?? $empresa;
			}

			$html = '';
			$html .='	<fieldset class="formulario">';
			$html .= '<legend>Modificar producto</legend>';
			$html .='	<div class="grupo-control">';
			$html .='		<label>Nombre del producto:</label> <input class="control" type="text" name="_nombreProducto" value="'.$nombrProd .'" required />';
			$html .='	</div>';
			$html .='	<div class="grupo-control">';
			$html .='		<label>Descripción:</label> <input class="control" type="text" name="_descrip" value="'.$descrip.'" required />';
			$html .='	</div>';
			$html .='	<div class="grupo-control">';
			$html .='		<label>Edad:</label> <input class="control" type="number" name="_edad" min ="1" max = "99" value="'.$edad.'" required />';
			$html .='	</div>';
			$html .='	<div class="grupo-control">';
			$html .='		<label>Jugadores:</label> <input class="control" type="number" name="_jugadores" min = "1" max = "20" value="'.$jugadores.'" required />';
			$html .='	</div>';
			$html .='	<div class="grupo-control">';
			$html .='		<label>link:</label> <input class="control" type="url" name="_link" value="'.$link.'" required />';
			$html .='	</div>';
			$html .='	<div class="grupo-control">';
			$html .='		<label>Empresa:</label> <input class="control" type="text" name="_empresa" value="'.$empresa.'" required />';
			$html .='	</div>';
			$html .='	<div class="grupo-control"><button type="submit" name="registro">Registrar</button></div>';
			$html .='</fieldset>';
			return $html;
		}
}

?>

<div id="contenido">
<?php
		$formu = new \es\ucm\fdi\aw\RegistroProducto();
		echo $formu->gestiona();
?>
</div>
