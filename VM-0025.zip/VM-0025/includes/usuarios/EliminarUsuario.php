<?php
namespace es\ucm\fdi\aw;

use es\ucm\fdi\aw\Aplicacion as App;
 	require_once __DIR__.'/../comun/config.php';
    require_once __DIR__.'/Usuario.php';
 ?>

 <div>
 <?php   
 	 
     $id = $_GET['id'];
     Usuario:: eliminarUsuario($id);
     Header("Location: ../../userTabla.php");
?>
</div>