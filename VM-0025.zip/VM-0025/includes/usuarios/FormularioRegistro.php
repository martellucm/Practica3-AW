<?php

namespace es\ucm\fdi\aw;
require_once __DIR__ .'/Usuario.php';

class FormularioRegistro extends Form
{

  const HTML5_EMAIL_REGEXP = '^[a-zA-Z0-9.!#$%&\'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$';

  public function __construct()
  {
    parent::__construct('registro');
  }
  
  protected function generaCamposFormulario ($datos)
  {
    $username = '';
    $password = '';
	$nombr = '';
	$email = '';
	$rol = 'user';
	$descr = '';
	$cumple = '';
    if ($datos) {
		$username = isset($datos['username']) ? $datos['username'] : $username;
		/* Similar a la comparación anterior pero con el operador ?? de PHP 7 */
		$password = $datos['password'] ?? $password;
		$password2 = isset($datos['password2']) ? $datos['password2'] : null;
		$nombre = isset($datos['nombre']) ? $datos['nombre'] : null;
		$email = isset($datos['email']) ? $datos['email'] : null;
		$cumple = isset($datos['cumple']) ? $datos['cumple'] : null;
		$descrip = isset($datos['descrip']) ? $datos['descrip'] : null;
    }

    $html = '';
	$html .= '<fieldset class = "formulario">';
	$html .= '<legend>Registro</legend>';
	$html .='	<div class="grupo-control">';
	$html .='		<label>Nombre de usuario</label> <input type="text" name="username" value="'.$username.'" required />';
	$html .='	</div>';
	$html .='	<div class="grupo-control">';
	$html .='		<label>Nombre completo</label> <input type="text" name="nombre" value="'.$nombr.'" required />';
	$html .='	</div>';
	$html .='	<div class="grupo-control">';
	$html .='		<label>Contrase�a</label> <input type="password" name="password" value="'.$password.'" required />';
	$html .='	</div>';
	$html .='	<div class="grupo-control"><label>Repita contrase�a</label> <input type="password" name="password2" /><br /></div>';
	
	$html .='	<div class="grupo-control">';
	$html .='		<label>Email</label> <input type="text" name="email" value="'.$email.'" required />';
	$html .='	</div>';
	$html .='	<div class="grupo-control">';
	$html .='		<label>Hablanos sobre ti</label> <input type="text" name="descrip" value="'.$descr.'" required />';
	$html .='	</div>';
	$html .='	<div class="grupo-control">';
	$html .='		<label>Fecha de nacimiento</label> <input type="date" name="cumple" value="'.$cumple.'" required />';
	$html .='	</div>';
	$html .='	<div class="grupo-control"><button type="submit" name="registro">Registrar</button></div>';
	$html .='</fieldset>';
	return $html;
  }

  /**
   * Procesa los datos del formulario.
   */
  protected function procesaFormulario($datos)
  {
    $result = array();
    $ok = true;
    $username = $datos['username'] ?? '' ;
    if (!$username ) {
      $result[] = 'El nombre de usuario no es valido';
      $ok = false;
    }

    $password = $datos['password'] ?? '' ;
    if ( ! $password ||  mb_strlen($password) < 4 ) {
      $result[] = 'La contrase�a no es v�lida';
      $ok = false;
    }
	
	$password2 = $datos['password2'] ?? '' ;
	if ( ! $password2 || strcmp($password, $password2) !== 0 ) {
		$result[] = "Los passwords deben coincidir";
		$ok = false;
	}

	$nombre = $datos['nombre'] ?? '';
	if(!$nombre){
		$result[] = 'El nombre no es v�lido';
		$ok = false;
	}
	
	$email = $datos['email'] ?? '';
	if(!$email){
		$result[] = 'El email no es v�lido';
		$ok = false;
	}
	
	$cumple = $datos['cumple'] ?? '';
	if(!$cumple){
		$result[] = 'La fecha de nacimiento no es v�lida';
		$ok = false;
	}
	
	$descrip = $datos['descrip'] ?? '';
	if(!$descrip || mb_strlen($descrip) < 10){
		$result[] = '�No seas t�mido! Cu�ntanos algo sobre ti.';
		$ok = false;
	}
	
    if ( $ok ) {
		$usuario = Usuario::crea($username, $nombre, $password, $email, '0', '0', '0', 'noob', 'user', $descrip, $cumple);
		if(!$usuario){
			$result[] = "El usuario ya existe";
		}
		else{
			$user = Usuario::login($username, $password);
			session_regenerate_id(true);
			Aplicacion::getSingleton()->login($user);
			$result = \es\ucm\fdi\aw\Aplicacion::getSingleton()->resuelve('/index.php');
		}
    }
    return $result;
  }
}
