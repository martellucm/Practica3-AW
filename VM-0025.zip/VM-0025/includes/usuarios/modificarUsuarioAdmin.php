<?php

namespace es\ucm\fdi\aw;
require_once __DIR__ .'/Usuario.php';

class ModifUsu extends Form
{

  const HTML5_EMAIL_REGEXP = '^[a-zA-Z0-9.!#$%&\'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$';

  public function __construct()
  {
    parent::__construct('modificarusu');
  }
  
  protected function generaCamposFormulario ($datos)
  {
	$usuario="";
	if(!isset($_POST['modificarusu'])){
		$id = $_GET['id'];
		$usuario = Usuario::buscaUsuarioID($id);
	}
	else{
		$usuario= Usuario::buscaUsuarioID($datos['id']);
	}
	
	$datos['id'] = $usuario->id();
	$datos['_nombre'] = $usuario->nombre();
	$datos['_email'] = $usuario->email();
	$datos['_descrip'] = $usuario->descrip();
	$datos['_cumple'] = $usuario->cumple();
    
    if ($datos) {
		/* Similar a la comparación anterior pero con el operador ?? de PHP 7 */
		$nombre = isset($datos['_nombre']) ? $datos['_nombre'] : null;
		$email = isset($datos['_email']) ? $datos['_email'] : null;
		$cumple = isset($datos['_cumple']) ? $datos['_cumple'] : null;
		$descrip = isset($datos['_descrip']) ? $datos['_descrip'] : null;
    }

    $html = '';
	$html .='	<fieldset class ="formulario">';
	$html .= '<legend>Modificar usuario</legend>';
	$html .='	<div class="grupo-control">';
	$html .='		<label>Nombre completo</label> <input class="control" type="text" name="_nombre" value="'.$usuario->nombre() .'" required />';
	$html .='	</div>';
	$html .='	<div class="grupo-control">';
	$html .='		<label>Email</label> <input class="control" type="text" name="_email" value="'.$usuario->email().'" required />';
	$html .='	</div>';
	$html .='	<div class="grupo-control">';
	$html .='		<label>Háblanos sobre ti</label> <input class="control" type="text" name="_descrip" value="'.$usuario->descrip().'" required />';
	$html .='	</div>';
	$html .='	<div class="grupo-control">';
	$html .='		<label>Fecha de nacimiento</label> <input class="control" type="date" name="_cumple" value="'.$usuario->cumple().'" required />';
	
	$html .='<input class="grupo-control" type="hidden" name="id" value="'.$usuario->id().'"/>';
	$html .='	<div class="grupo-control"><button type="submit"  name="modificarusu">Modificar</button></div>';
	$html .='</fieldset>';
	return $html;
  }

  /**
   * Procesa los datos del formulario.
   */
  protected function procesaFormulario($datos)
  {
    $result = array();
    $ok = true;
	

	$nombre = $datos['_nombre'] ?? '';
	if(!$nombre){
		$result[] = 'El nombre no es válido';
		$ok = false;
	}
	
	$email = $datos['_email'] ?? '';
	if(!$email){
		$result[] = 'El email no es válido';
		$ok = false;
	}
	
	$cumple = $datos['_cumple'] ?? '';
	if(!$cumple){
		$result[] = 'La fecha de nacimiento no es válida';
		$ok = false;
	}
	
	$descrip = $datos['_descrip'] ?? '';
	if(!$descrip || mb_strlen($descrip) < 10){
		$result[] = '¡No seas tímido! Cuéntanos algo sobre ti.';
		$ok = false;
	}
	
    if ( $ok ) {
		$id = $datos['id'];
		Usuario::actualizaUsu($id, $nombre, $email, $descrip, $cumple);
		$result = \es\ucm\fdi\aw\Aplicacion::getSingleton()->resuelve('/userTabla.php');
    }
    return $result;
  }
}
