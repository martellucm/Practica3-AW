
<div class = "noti">
	<h1>Noticias de la semana</h1>	
	<h2>LA LOLA</h2>
	<p> La llegada de Lolita Lola ha avivado uno de los escenarios preferidos de los amantes de los videojuegos: el Japón medieval. Peleas a las luz de la luna en campos de bambú, cargas de ejércitos samurai, infiltraciones en castillos, katanas y shuriken. Toda una serie de ingredientes que han asentado un pequeño género dentro de la industria, entre los que se encuentran juegos ya legendarios como Pepito Pepe, curiosidades como El juego de mi coño, o nuevas apuestas como El juego del amor, que presumiblemente llegará a PS4 este mismo año.</p>

	




 </div>

