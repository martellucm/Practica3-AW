<?php
	namespace es\ucm\fdi\aw;
	use es\ucm\fdi\aw\Aplicacion as App;

	require_once __DIR__. '/../comun/config.php';
	require_once __DIR__.'/GestionaTorneo.php';
	require_once __DIR__.'/../comun/Form.php';
	require_once __DIR__. '/Inscrito.php';
	require_once __DIR__. '/torneo.php';
	require_once __DIR__. '/../usuarios/Usuario.php';
	require_once __DIR__. '/../productos/Producto.php';

	class FormularioInscrip extends Form{

		const HTML5_EMAIL_REGEXP = '^[a-zA-Z0-9.!#$%&\'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$';


		  public function __construct()
		  {
		    parent::__construct('formInscrip');
		  }

		protected function procesaFormulario($datos){

			$foresultrmu = array();
			$erroresFormulario = array();
			$ok = true;

			$date = getdate();
			 $hoy = $date['year'];
			 $hoy .= '-';
			 $hoy .= $date['mon'];
			 $hoy .= '-';
			 $hoy .= $date['mday'];
			$idJuego= $datos['juego'];
			$nom =$_SESSION['nombre'];
			$id = Usuario::buscaUsuario($nom);
			$viernes = $date['wday'] == 5? 1: 0;

			if (!$id) {
				$erroresFormulario[] = "El juego tiene que existir";
				$ok = false;
			}

			if ($ok) {
				$resul = Inscrito::inscribe($id->id(), $idJuego, $viernes, 0, $hoy);
				if($resul instanceof Inscrito){
					$erroresFormulario = \es\ucm\fdi\aw\Aplicacion::getSingleton()->resuelve('/torneo.php');
				}else{
					$erroresFormulario[] = "El usuario ya está inscrito";
				}
			}

			return $erroresFormulario;

		}

		 protected function generaCamposFormulario($datosIniciales)
		{

			/*
			* En caso de que hubiera un error se mantienen
			* los datos para que puedas modificarlos
			*/

			$arr = GestionaTorneo::getTorneos();
			$html = ''; // String que genera el html
			$html .= '<fieldset class = "formulario">';
            $html .= '<legend>Inscribirse a un torneo</legend>';
            $html .= '	<div class="grupo-control">';

				 if(!empty($arr)){
					$html .= '<select name="juego">';
					foreach($arr as $row){
						$val = Torneo::buscarTorneoIdJuego($row['id']);
						$jug = Product::buscaProduco($row['juego']);
						$html .= '<option value="'.$val.'">'.$jug->nombreProd().' - '.$row['fecha'].'</option>';
					}
					$html .= '</select>';
				 }
				 else{
					$html .= '<p>ERROR</p>';
				 }
            $html .= '  <div class="grupo-control"><button type="submit" name="login">Inscribirse</button></div>';
			$html .= '</fieldset>';
			return $html;
		}


	}
?>

	<div id="inscri_tour">

		<?php
			$formu = new \es\ucm\fdi\aw\FormularioInscrip();
			echo $formu->gestiona();
		?>
	</div>
