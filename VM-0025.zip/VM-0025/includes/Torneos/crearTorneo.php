<?php
	namespace es\ucm\fdi\aw;
	use es\ucm\fdi\aw\Aplicacion as App;
	require_once __DIR__.'/../comun/config.php';
	require_once __DIR__.'/../comun/Form.php';
	require_once __DIR__.'/torneo.php';

class RegistroTorneo extends Form {

	const HTML5_EMAIL_REGEXP = '^[a-zA-Z0-9.!#$%&\'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$';

	  public function __construct()
	  {
	    parent::__construct('formTorneo');
	  }

	protected function procesaFormulario($datos){

			$result = array();
    		$ok = true;

			$idjuego = $datos['_id'] ?? '';
			
			if (!$idjuego && $idjuego != 0) {
				$result[] = "Id de juego no valida.";
				$ok = false;
			}

			$fecha = $datos['_fecha'] ?? '';
			if (!$fecha) {
				$result[] = "fecha no valida.";
				$ok = false;
			}

			
			if ($ok) {
				$torneo = Torneo::crea($idjuego, $fecha);
				if (! $torneo ) {
					$result[] = "El torneo ya existe";
				} else {
					$result = \es\ucm\fdi\aw\Aplicacion::getSingleton()->resuelve('/torneo.php');
				}
			}

			return $result;
		}

	protected function generaCamposFormulario($datosIniciales){
			$fecha = '';
			$id = '';

			/*
			* En caso de que hubiera un error se mantienen
			* los datos para que puedas modificarlos
			*/
			if ($datosIniciales){
				$id = $datosIniciales['_id'] ?? $id;
				$fecha = $datosIniciales['_fecha'] ?? $fecha;
			}


			$html = '';
			$html .='	<fieldset class = "formulario"> <h1>Registro de Torneo</h1>';
			$html .='	<div class="grupo-control">';
			$html .='		<label>Juego del torneo:</label> <select name=_id>';
								$app = Aplicacion::getSingleton();
						        $conn = $app->conexionBd();
								$query = sprintf("SELECT id, nombreProd FROM producto"); 
								$rs = $conn->query($query);
	       						$result = false;
								while ($row = mysqli_fetch_array($rs)) { 
								$nombre = $row["nombreProd"];
			$html .='			<option value ='. $row['id'].'>'.$nombre.'</option>' ;
								} 
			$html .='	</select>';
			$html .='	</div>';
			$html .='	<div class="grupo-control">';
			$html .='		<label>Fecha del Torneo:</label> <input class="control" type="date" name="_fecha" value="'.$fecha.'" required />';
			$html .='	</div>';

			$html .='	<div class="grupo-control"><button type="submit" name="registro">Añadir</button></div>';
			$html .='</fieldset>';
			return $html;
		}
}

?>





<div id="contenido">
<?php
		$formu = new  \es\ucm\fdi\aw\RegistroTorneo();
		echo $formu->gestiona();
?>
</div>
