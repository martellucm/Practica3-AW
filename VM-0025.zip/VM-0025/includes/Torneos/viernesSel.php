	<div id="selectVier">
		<h2>Selecciona tu juego de la semana</h2>
		<!--Aquí poner la función que devuelva 3 randoms-->
		<form action="" method="POST">
			<input type="radio" name="bttn_vier">Primero 
			<input type="radio" name="bttn_vier">Segundo
			<input type="radio" name="bttn_vier">Tercero
			<input type="radio" name="bttn_vier">Cuarto
			<input type="submit" name="Inscribirse"> 
		</form>
	</div>