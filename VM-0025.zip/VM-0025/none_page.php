<?php
require_once __DIR__.'/includes/comun/config.php';
?>
<!DOCTYPE HTML>
<html lang="es">
  <head>
    <title>My Chuster Games - NONE PAGE</title>
    <link rel="stylesheet" type="text/css" href="css/estilo.css" />
    <meta charset="utf-8">
  </head>
<body>
  <div id ="contenedor">
    <?php require'includes/comun/cabecera.php'?>
    <div id="none">
      <h1>AÚN NO SE HA AÑADIDO NINGUNA FUNCIONALIDAD</h1>
      <p>Pronto se actualizará la página web</p>
    </div>
  </div>
</body>
</html>
