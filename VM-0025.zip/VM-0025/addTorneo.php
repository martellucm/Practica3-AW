<?php
namespace es\ucm\fdi\aw;

use es\ucm\fdi\aw\Aplicacion as App;
require_once __DIR__.'/includes/comun/config.php';
?>
<!DOCTYPE html>
<html lang="es">
  <head>
    <title>My Chuster Games</title>
    <link rel="stylesheet" type="text/css" href="css/estilo.css" />
    <meta charset="utf-8">
  </head>
<body>
  <div id ="contenedor">
  	   <?php require'includes/comun/cabecera.php'?>
  	<div id = "contenido">
  	  <?php require'includes/Torneos/crearTorneo.php'?>
	 }
	?>

</body>
</html>
