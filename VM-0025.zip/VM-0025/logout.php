<?php

require_once __DIR__.'/includes/comun/config.php';

$app->logout();

?><!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="css/estilo.css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>MyChuster Games</title>
</head>

<body>

<div id="contenedor">

<?php
	require("includes/comun/cabecera.php");
?>

	<div id="contenido">
		<h1>Hasta pronto!</h1>
	</div>



</div>

</body>
</html>
